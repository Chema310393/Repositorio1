/**
*Realiza tu primera clase HolaMundo
*@author José María Romero Ruiz
*@version 1.0
*/
class HolaMundo{
	public static void main(String[] args){
		System.out.println("Hola mundo!\nSoy José María Romero Ruiz");
	}
}